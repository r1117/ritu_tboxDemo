
#import <UIKit/UIKit.h>

@class DiscussViewController;

@protocol DiscussViewControllerDelegate <NSObject>
- (void)discussViewControllerDidCancel: (DiscussViewController *)controller;
@end


@interface DiscussViewController : UIViewController

@property (nonatomic, copy) NSString *apiKey;
@property (nonatomic, copy) NSString *sessionId;
@property (nonatomic, copy) NSString *token;

@property (nonatomic, copy) NSString *rid;
@property (nonatomic, copy) NSString *arid;
@property (nonatomic, weak) id <DiscussViewControllerDelegate> delegate;

- (IBAction)ok:(id)sender;
- (IBAction)Rec:(id)sender;
@end
