
#import "DiscussViewController.h"
#import <OpenTok/OpenTok.h>
#import "AFNetworking.h"

@interface DiscussViewController () <OTSessionDelegate, OTSubscriberKitDelegate, OTPublisherDelegate>
@end

@implementation DiscussViewController {
    OTSession* _session;
    OTPublisher* _publisher;
    OTSubscriber* _subscriber;
}

static double widgetHeight = 240;
static double widgetWidth = 320;
static bool subscribeToSelf = NO;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"VIEW LOADED DISC %@", self.rid);
    NSDictionary *body = @{@"roomName": self.rid};

    AFSecurityPolicy* policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    [policy setValidatesDomainName:NO];
    [policy setAllowInvalidCertificates:YES];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager setSecurityPolicy:policy];
     manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [manager POST:@"https://10.10.10.74:3001/api/session" parameters:body progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            self.apiKey = [responseObject objectForKey:@"apiKey"];
            self.sessionId = [responseObject objectForKey:@"sessionId"];
        }
        
        NSDictionary *body = @{@"sessionId": self.sessionId};
        //get token for this particpant
        [manager POST:@"https://10.10.10.74:3001/api/token" parameters:body progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"JSON1: %@", responseObject);
            if ([responseObject isKindOfClass:[NSDictionary class]]) {
                self.token = [responseObject objectForKey:@"token"];
            }
            //start auto_connect
            
            _session = [[OTSession alloc] initWithApiKey:self.apiKey
                                               sessionId:self.sessionId
                                                delegate:self];
            [self doConnect];
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)ok:(id)sender {
    NSLog(@"DONE");
    OTError *error = nil;
    [_session disconnect:&error];
    if (error) {
        NSLog(@"Failed to disconnect");
    }
    [self.delegate discussViewControllerDidCancel:self];
}
- (void)stopRec:(id)sender {
    
    NSLog(@"Stop Record");
    if (!self.rid || !_session)
    {
        NSLog(@"Session not ready");
        return;
    }
    
    
    if (self.arid) {
        NSLog(@"Archive req");
        NSDictionary *body = @{@"aid": self.arid};
        
        AFSecurityPolicy* policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        [policy setValidatesDomainName:NO];
        [policy setAllowInvalidCertificates:YES];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        [manager setSecurityPolicy:policy];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        [manager POST:@"https://10.10.10.74:3001/api/arstop" parameters:body progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"JSON: %@", responseObject);
            self.arid = NULL;
            UIBarButtonItem* recBut = [[UIBarButtonItem alloc]
                                       initWithTitle:NSLocalizedString(@"Rec", @"")
                                       style:UIBarButtonItemStylePlain
                                       target:self
                                       action:@selector(Rec:)];
            self.navigationItem.rightBarButtonItems = [NSArray arrayWithObject:recBut];
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
}

- (IBAction)Rec:(id)sender {
    NSLog(@"Record");
    if (!self.rid || !_session)
    {
        NSLog(@"Session not ready");
        return;
    }
    
    
    if (!self.arid) {
        NSLog(@"Archive req");
        NSDictionary *body = @{@"sessionId": self.sessionId};
        
        AFSecurityPolicy* policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        [policy setValidatesDomainName:NO];
        [policy setAllowInvalidCertificates:YES];
    
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        [manager setSecurityPolicy:policy];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
        [manager POST:@"https://10.10.10.74:3001/api/arstart" parameters:body progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"JSON: %@", responseObject);
            if ([responseObject isKindOfClass:[NSDictionary class]]) {
                self.arid = [responseObject objectForKey:@"aid"];
            }
            
            UIBarButtonItem* stopBut = [[UIBarButtonItem alloc]
                                        initWithTitle:NSLocalizedString(@"StopRec", @"")
                                        style:UIBarButtonItemStylePlain
                                        target:self
                                        action:@selector(stopRec:)];
            self.navigationItem.rightBarButtonItems = [NSArray arrayWithObject:stopBut];
        
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:
(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if (UIUserInterfaceIdiomPhone == [[UIDevice currentDevice]
                                      userInterfaceIdiom])
    {
        return NO;
    } else {
        return YES;
    }
}

- (void)doConnect
{
    OTError *error = nil;
    
    [_session connectWithToken:self.token error:&error];
    if (error)
    {
        [self showAlert:[error localizedDescription]];
    }
}

- (void)doPublish
{
    _publisher =
    [[OTPublisher alloc] initWithDelegate:self
                                     name:[[UIDevice currentDevice] name]];
    
    OTError *error = nil;
    [_session publish:_publisher error:&error];
    if (error)
    {
        [self showAlert:[error localizedDescription]];
    }
    
    [self.view addSubview:_publisher.view];
    [_publisher.view setFrame:CGRectMake(0, 0, widgetWidth, widgetHeight)];
}

- (void)cleanupPublisher {
    [_publisher.view removeFromSuperview];
    _publisher = nil;
    // this is a good place to notify the end-user that publishing has stopped.
}

- (void)doSubscribe:(OTStream*)stream
{
    _subscriber = [[OTSubscriber alloc] initWithStream:stream delegate:self];
    
    OTError *error = nil;
    [_session subscribe:_subscriber error:&error];
    if (error)
    {
        [self showAlert:[error localizedDescription]];
    }
}

- (void)cleanupSubscriber
{
    [_subscriber.view removeFromSuperview];
    _subscriber = nil;
}

# pragma mark - OTSession delegate callbacks

- (void)sessionDidConnect:(OTSession*)session
{
    NSLog(@"sessionDidConnect (%@)", session.sessionId);
    
    // Step 2: We have successfully connected, now instantiate a publisher and
    // begin pushing A/V streams into OpenTok.
    [self doPublish];
}

- (void)sessionDidDisconnect:(OTSession*)session
{
    NSString* alertMessage =
    [NSString stringWithFormat:@"Session disconnected: (%@)",
     session.sessionId];
    NSLog(@"sessionDidDisconnect (%@)", alertMessage);
}


- (void)session:(OTSession*)mySession
  streamCreated:(OTStream *)stream
{
    NSLog(@"session streamCreated (%@)", stream.streamId);
    
    // Step 3a: (if NO == subscribeToSelf): Begin subscribing to a stream we
    // have seen on the OpenTok session.
    if (nil == _subscriber && !subscribeToSelf)
    {
        [self doSubscribe:stream];
    }
}

- (void)session:(OTSession*)session
streamDestroyed:(OTStream *)stream
{
    NSLog(@"session streamDestroyed (%@)", stream.streamId);
    
    if ([_subscriber.stream.streamId isEqualToString:stream.streamId])
    {
        [self cleanupSubscriber];
    }
}

- (void)  session:(OTSession *)session
connectionCreated:(OTConnection *)connection
{
    NSLog(@"session connectionCreated (%@)", connection.connectionId);
}

- (void)    session:(OTSession *)session
connectionDestroyed:(OTConnection *)connection
{
    NSLog(@"session connectionDestroyed (%@)", connection.connectionId);
    if ([_subscriber.stream.connection.connectionId
         isEqualToString:connection.connectionId])
    {
        [self cleanupSubscriber];
    }
}

- (void) session:(OTSession*)session
didFailWithError:(OTError*)error
{
    NSLog(@"didFailWithError: (%@)", error);
}

# pragma mark - OTSubscriber delegate callbacks

- (void)subscriberDidConnectToStream:(OTSubscriberKit*)subscriber
{
    NSLog(@"subscriberDidConnectToStream (%@)",
          subscriber.stream.connection.connectionId);
    assert(_subscriber == subscriber);
    [_subscriber.view setFrame:CGRectMake(0, widgetHeight, widgetWidth,
                                          widgetHeight)];
    [self.view addSubview:_subscriber.view];
}

- (void)subscriber:(OTSubscriberKit*)subscriber
  didFailWithError:(OTError*)error
{
    NSLog(@"subscriber %@ didFailWithError %@",
          subscriber.stream.streamId,
          error);
}

# pragma mark - OTPublisher delegate callbacks

- (void)publisher:(OTPublisherKit *)publisher
    streamCreated:(OTStream *)stream
{
    // Step 3b: (if YES == subscribeToSelf): Our own publisher is now visible to
    // all participants in the OpenTok session. We will attempt to subscribe to
    // our own stream. Expect to see a slight delay in the subscriber video and
    // an echo of the audio coming from the device microphone.
    if (nil == _subscriber && subscribeToSelf)
    {
        [self doSubscribe:stream];
    }
}

- (void)publisher:(OTPublisherKit*)publisher
  streamDestroyed:(OTStream *)stream
{
    if ([_subscriber.stream.streamId isEqualToString:stream.streamId])
    {
        [self cleanupSubscriber];
    }
    
    [self cleanupPublisher];
}

- (void)publisher:(OTPublisherKit*)publisher
 didFailWithError:(OTError*) error
{
    NSLog(@"publisher didFailWithError %@", error);
    [self cleanupPublisher];
}

- (void)showAlert:(NSString *)string
{
    // show alertview on main UI
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"OTError"
                                                        message:string
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil] ;
        [alert show];
    });
}

@end
