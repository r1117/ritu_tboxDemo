
#import "FirstViewController.h"
#import "Topic.h"
#import "TopicViewController.h"
#import "AFNetworking.h"


@interface FirstViewController ()
{
    	NSMutableArray *players;
        //AFHTTPSessionManager *manager;
}
@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    players = [NSMutableArray arrayWithCapacity:20];

    //manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:@"https://127.0.0.1:3001/"]];
    //AFSecurityPolicy* policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];

    AFSecurityPolicy* policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    [policy setValidatesDomainName:NO];
    [policy setAllowInvalidCertificates:YES];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager setSecurityPolicy:policy];
    
    [manager GET:@"https://10.10.10.74:3001/api/listroom" parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        if ([responseObject isKindOfClass:[NSArray class]]) {
            NSArray *responseArray = responseObject;
            for (id tempObject in responseArray) {
                if ([tempObject isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *resDict = tempObject;
                    NSLog(@"Single element: %@", resDict);
                    Topic *topic = [[Topic alloc] init];
                    topic.name = [resDict objectForKey:@"q"];
                    topic.category = [resDict objectForKey:@"cat"];
                    topic.rid  = [resDict objectForKey:@"roomName"];
                    topic.rating = 4;
                    [players addObject:topic];
                }
            }
        }
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
// This will get called too before the view appears
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{    
    if ([[segue identifier] isEqualToString:@"Link1"]) {
        UINavigationController *navigationController = [segue destinationViewController];
        TopicViewController *playersViewController =
        [[navigationController viewControllers] objectAtIndex:0];
        playersViewController.topics = players;
        
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
