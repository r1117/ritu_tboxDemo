
#import <Foundation/Foundation.h>

@interface Topic : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *category;
@property (nonatomic, copy) NSString *rid;
@property (nonatomic, assign) int rating;

@end
