

#import "Topic.h"

@implementation Topic

@end
