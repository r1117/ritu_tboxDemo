

#import <UIKit/UIKit.h>

@interface TopicCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *nameLabel;
@property (nonatomic, strong) IBOutlet UILabel *gameLabel;
@property (nonatomic, strong) IBOutlet UIImageView *ratingImageView;
@property (nonatomic, copy) NSString *rid;

@end
