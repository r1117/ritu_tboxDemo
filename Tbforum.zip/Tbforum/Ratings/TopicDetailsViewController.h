
#import <UIKit/UIKit.h>
#import "Topic.h"
#import "TopicPickerViewController.h"

@class TopicDetailsViewController;

@protocol TopicDetailsViewControllerDelegate <NSObject>
- (void)topicDetailsViewControllerDidCancel:
(TopicDetailsViewController *)controller;
- (void)topicDetailsViewController:
(TopicDetailsViewController *)controller
                       didAddPlayer:(Topic *)Topic;
@end

@interface TopicDetailsViewController : UITableViewController <TopicPickerViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;

@property (nonatomic, weak) id <TopicDetailsViewControllerDelegate> delegate;

- (IBAction)cancel:(id)sender;
- (IBAction)done:(id)sender;

@end
