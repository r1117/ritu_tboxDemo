
#import "TopicDetailsViewController.h"

@interface TopicDetailsViewController ()

@end

@implementation TopicDetailsViewController
{
    	NSString *game;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	if ((self = [super initWithCoder:aDecoder]))
	{
		NSLog(@"init TopicDetailsViewController");
		game = @"Session";
	}
	return self;
}

- (IBAction)cancel:(id)sender
{
	[self.delegate topicDetailsViewControllerDidCancel:self];
}

- (IBAction)done:(id)sender
{
	Topic *topic = [[Topic alloc] init];
	topic.name = self.nameTextField.text;
	topic.category = game;
	topic.rating = 1;
    topic.rid = [[NSUUID UUID] UUIDString];
	[self.delegate topicDetailsViewController:self
                                  didAddPlayer:topic];
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	self.detailLabel.text = game;
}

#pragma mark - GamePickerViewControllerDelegate

- (void)gamePickerViewController:
(TopicPickerViewController *)controller
                   didSelectGame:(NSString *)theGame
{
	game = theGame;
	self.detailLabel.text = game;
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section == 0)
		[self.nameTextField becomeFirstResponder];
}

- (void)dealloc
{
	NSLog(@"dealloc PlayerDetailsViewController");
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if ([segue.identifier isEqualToString:@"PickGame"])
	{
		TopicPickerViewController *topicPickerViewController =
        segue.destinationViewController;
		topicPickerViewController.delegate = self;
		topicPickerViewController.game = game;
	}
}

@end
