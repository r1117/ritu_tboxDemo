

#import <UIKit/UIKit.h>

@class TopicPickerViewController;

@protocol TopicPickerViewControllerDelegate <NSObject>
- (void)gamePickerViewController:(TopicPickerViewController *)controller
                   didSelectGame:(NSString *)game;
@end

@interface TopicPickerViewController : UITableViewController

@property (nonatomic, weak) id <TopicPickerViewControllerDelegate> delegate;
@property (nonatomic, strong) NSString *game;

@end
