
#import <UIKit/UIKit.h>
#import "TopicDetailsViewController.h"
#import "DiscussViewController.h"

@interface TopicViewController : UITableViewController<TopicDetailsViewControllerDelegate,DiscussViewControllerDelegate>
@property (nonatomic, strong) NSMutableArray *topics;
@end
