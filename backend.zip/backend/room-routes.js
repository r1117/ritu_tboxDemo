var express = require('express'),
    _  = require('lodash');
var Opentok = require('opentok');

var app = module.exports = express.Router();
var rooms = [{roomName:"RoomID1", q:"How to create session on server?", cat:"Session"},{roomName:"RoomID2", q:"How to join session?", cat:"Session"}]

app.post('/api/addroom', function(req, res) {
  if (!req.body.roomName) {
    return res.status(400).send("Req parameters missing");
  }
  if (_.find(rooms, {roomName: req.body.roomName})) {
   return res.status(400).send("A room already exists");
  }
  var token = Math.random();
  var e = {
       roomName:req.body.roomName, 
       q:req.body.q,
       cat:req.body.cat
  }
  rooms.push(e);
  res.status(201).send(e);
});

app.get('/api/listroom', function(req, res) {
   res.status(201).send(rooms);
});


var apiKey = '45302582';
var apiSecret = '13c1a4b0500cb19a2b5217de2374fbeab79a3612';
opentok = new Opentok(apiKey, apiSecret);


app.post('/api/token', function(req, res) {
   if (!req.body.sessionId) {
      return res.status(400).send({e:"You must send the sessionId"});
   }
   var sid = req.body.sessionId;
   console.log("Token for room sessionId " + sid);

   var token = opentok.generateToken(sid);
   var apitok = {
           apiKey: apiKey,
           sessionId: sid,
           token: token
   }
   console.log("send token");
   console.log(apitok)
   res.status(201).send(apitok);
   //res.status(201).send({ token: apitok });
});

app.post('/api/session', function(req, res) {

   if (!req.body.roomName) {
      return res.status(400).send({e:"You must send the roomName"});
   }
   console.log(req.body.roomName);
   var room = _.find(rooms, {roomName: req.body.roomName});

   if (room) {
       console.log("found room");
       if (room.sessionId) {
           console.log("found room existing sess");
           var apitok = {
               apiKey: apiKey,
               sessionId: room.sessionId,
               token: room.token,
           }
           res.status(201).send(apitok);
           //res.status(201).send({ token: apitok });
           return;
       }
   }

   opentok.createSession(function(err, session) {
       console.log('create sess');
       console.log(rooms)
       if (err) {
          console.log(err);
          return res.status(400).send({e:"error generating...session"});
       }
       var robj = {
           roomName:req.body.roomName,
           sessionId:session.sessionId,
           q:room.q,
           cat:room.cat
       }
       if (room) {
          console.log("insert");
          var index = _.indexOf(rooms, room);
          console.log(index);
          rooms.splice(index, 1, robj);
       } else {
          rooms.push(robj);
       }

       console.log("new rooms");
       console.log(rooms)

       var apitok = {
           apiKey: apiKey,
           sessionId: session.sessionId
       }
       console.log("Sending..");
       console.log(apitok)
       res.status(201).send(apitok);
       //res.status(201).send({ token: apitok });
    });
});

app.post('/api/arstart', function(req, res) {
   if (!req.body.sessionId) {
      return res.status(400).send("You must send the sessionid");
   }
   var sid = req.body.sessionId;
   console.log("Ar start request" +  sid);
   opentok.startArchive(sid, { name: 'Important Presentation' }, function(err, archive) {
     if (err) {
       console.log("Err archive");
       console.log(err)
       return res.status(400).send("Could not create archive");
     } else {
       console.log("new archive:" + archive.id);
       res.status(201).send({ aid: archive.id });
     }
   });
});

app.post('/api/arstop', function(req, res) {
   if (!req.body.aid) {
      return res.status(400).send("You must send the archiveID");
   }
   var aid = req.body.aid;
   opentok.stopArchive(aid, function(err, archive) {
     if (err) {
       return res.status(400).send("Could not stop archive");
     } else {
       res.status(201).send({ aid: archive.id });
     }
   });
}) 
 
app.get('/api/arlist', function(req, res) {
   opentok.listArchives({offset:100, count:50}, function(error, archives, totalCount) {
          if (error) return console.log("error:", error);
          console.log(totalCount + " archives");
          for (var i = 0; i < archives.length; i++) {
            console.log(archives[i].id);
          }
          res.status(201).send(archives)
    });
})
