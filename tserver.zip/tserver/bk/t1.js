import Koa from 'koa';
import Router from 'koa-router';
import Serve from 'koa-better-static';
import Opentok from 'opentok';
import Tmpl from 'koa-views';

const koa = new Koa();
//const app = new Router();

const apiKey = '45520432';
const apiSecret = '13c1a4b0500cb19a2b5217de2374fbeab79a3612';
const opentok = new Opentok(apiKey, apiSecret);
const token = 'test';
const sessionId = 'sessionId';

/*
opentok.createSession(function(err, session) {
  if (err) throw err;
  app.set('sessionId', session.sessionId);
  init();
});
*/

//koa.use(Serve(__dirname + '/webapp'));
//koa.use(Tmpl(__dirname + '/webapp', {map: { ejs: 'ejs' }}));
koa.use(Tmpl(__dirname + '/webapp'));

koa.use(async function (ctx, next) {
  ctx.state = { 
    apiKey: apiKey,
    sessionId: sessionId,
    token: token
  }
  await ctx.render('index.ejs')
/*
  await ctx.render('index.ejs', {
    apiKey: apiKey,
    sessionId: sessionId,
    token: token
  });
*/
});

/*
app.get('/:name', async (ctx) => {
  ctx.body = `Hello, ${ctx.params.name}!\n`;
});

app.get('/:token', async (ctx) => {
  let sessionId = app.get('sessionId'),
  let token = opentok.generateToken(sessionId);
});
*/

function init () {
  //koa.use(app.routes());
  koa.listen(3000);
}
init();
