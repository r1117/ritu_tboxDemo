import Koa from 'koa';
import Router from 'koa-router';
import Serve from 'koa-better-static';
import Tmpl from 'koa-views';
import Json from 'koa-json';
import Opentok from 'opentok';

const koa = new Koa();
const app = new Router();

koa.context.db = new Map();
const map = koa.context.db;

const apiKey = '45302582';
const apiSecret = '13c1a4b0500cb19a2b5217de2374fbeab79a3612';
const opentok = new Opentok(apiKey, apiSecret);

async function app_temp(ctx) {

  let sessionId = map.get('sessionId');

  let tokenOptions = {};
  //tokenOptions.role = "publisher";
  //tokenOptions.data = "username=bob

  let token = opentok.generateToken(sessionId, tokenOptions);

  ctx.state = { 
    apiKey: apiKey,
    sessionId: sessionId,
    token: token
  }

  await ctx.render('index.ejs')
}

async function token(ctx) {
  let sessionId = map.get('sessionId');
  let token = opentok.generateToken(sessionId);
  let apitok = { 
    apiKey: apiKey,
    sessionId: sessionId,
    token: token
  }
  ctx.body = apitok;
};

function setup_route_server() {
   koa.use(Serve(__dirname + '/webapp'));
   koa.use(Tmpl(__dirname + '/webapp'));
   koa.use(Json());
   app.get('/', app_temp);
   app.get('/token', token);
   koa.use(app.routes());
   koa.listen(3000);
   console.log("Ready....");
}

opentok.createSession(function(err, session) {
  if (err) throw err;
  map.set('sessionId', session.sessionId);
  setup_route_server();
});

//setup_route_server();
