console.log("ok")

var session = OT.initSession(apiKey, sessionId)
    .on('streamCreated', function(event) {
    session.subscribe(event.stream);
})
.connect(token, function(error) {
    var publisher = OT.initPublisher();
    session.publish(publisher);
});
